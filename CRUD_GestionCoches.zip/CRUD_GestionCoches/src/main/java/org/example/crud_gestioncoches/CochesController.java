package org.example.crud_gestioncoches;

import com.mongodb.client.*;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import org.bson.Document;


import javafx.scene.control.TableColumn;


public class CochesController {
    public TextField tf_matricula;
    public TextField tf_marca;
    public TextField tf_modelo;
    public ComboBox cb_listaTipo;
    public TableView tv_tabla;
    public TableColumn columMatricula;
    public TableColumn columMarca;
    public TableColumn columModelo;
    public TableColumn columTipo;

    private ObservableList<Coche> cocheList;

    public CochesController(TableView<Coche> tableView) {
        this.tv_tabla = tableView;
        this.cocheList = FXCollections.observableArrayList();
        cargarCoches();
    }

    private void cargarCoches() {


        try (MongoClient mongoClient = MongoClients.create("mongodb://admin:1234@localhost:27017/?authSource=admin")) {
            MongoDatabase database = mongoClient.getDatabase("TallerNuevo");
            MongoCollection<Document> collection = database.getCollection("coches");

            // Recuperar los coches de MongoDB
            FindIterable<Document> documents = collection.find();
            for (Document doc : documents) {
                String marca = doc.getString("marca");
                String modelo = doc.getString("modelo");
                String matricula = doc.getString("matricula");
                String tipo= doc.getString("tipo");

                // Crear un objeto Coche y añadirlo a la lista
                int id=doc.getInteger("_id");
                cocheList.add(new Coche(id,marca, modelo, matricula, tipo));
            }
        } catch (Exception e) {
            System.err.println("Error al cargar coches: " + e.getMessage());
        }
    }

    public void Limpiar(ActionEvent actionEvent) {
        tf_matricula.setText("");
        tf_marca.setText("");
        tf_modelo.setText("");

    }

    public void Nuevo(ActionEvent actionEvent) {
        // Crear un nuevo coche y guardarlo en MongoDB
        try (MongoClient mongoClient = MongoClients.create("mongodb://admin:1234@localhost:27017/?authSource=admin")) {
            MongoDatabase database = mongoClient.getDatabase("TallerNuevo");
            MongoCollection<Document> collection = database.getCollection("coches");

            // Crear un nuevo documento con los datos del coche
            Document nuevoCoche = new Document("matricula", tf_matricula.getText())
                    .append("marca", tf_marca.getText())
                    .append("modelo", tf_modelo.getText())
                    .append("tipo", cb_listaTipo.getSelectionModel().getSelectedItem());

            // Insertar el nuevo coche en la colección
            collection.insertOne(nuevoCoche);

            // Mensaje de éxito
            System.out.println("Coche añadido exitosamente.");
        } catch (Exception e) {
            // Manejar errores de conexión o inserción
            System.err.println("Error al añadir el coche: " + e.getMessage());
        }
    }

    public void Modificar(ActionEvent actionEvent) {
    }

    public void Eliminar(ActionEvent actionEvent) {
    }

    public void tablaCoches(MouseEvent mouseEvent) {

    }

}