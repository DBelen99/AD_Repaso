package org.example.crud_gestioncoches;

import com.google.gson.Gson; //importante importar
import org.bson.Document; //importante importar
import com.mongodb.MongoClient;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoCursor;
import com.mongodb.client.MongoDatabase;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;


import java.io.IOException;

public class Main extends Application {
    @Override
    public void start(Stage stage) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("GestionCoches.fxml"));
        Scene scene = new Scene(fxmlLoader.load());
        stage.setTitle("Gestion de coches");
        stage.setScene(scene);
        stage.show();
    }




    public static void main(String[] args) {
        MongoClient con;
        MongoCollection<Document> coleccion=null;
        String json;
        Document doc;


        try{
            con=ConnectionDB.conectar(); //nos conectamos  a la BD
            MongoDatabase database=con.getDatabase("TallerNuevo"); //el metodo getDatabase() nos permite seleccionar la BD, y si no existe la crea
            coleccion= database.getCollection("coches"); //creo coleccion coches. coleccion=tabla

        }catch (Exception exception){
            System.err.println(exception.getClass().getName()+" : "+exception.getMessage());
        }
//
//        //Trabajar con objetos en java utilizando gson
//        Coche coche1 = new Coche(); // Creo un objeto
//        coche1.set_id(1);
//        coche1.setMatricula("6666HHH");
//        coche1.setMarca("Renault");
//        coche1.setModelo("Clio");
//        coche1.setTipo("Deportivo");
//
//        Coche coche2 = new Coche(); // Creo un objeto
//        coche1.set_id(2);
//        coche2.setMatricula("5555BCD");
//        coche2.setMarca("Ford");
//        coche2.setModelo("SMax");
//        coche2.setTipo("Familiar");
//
//        // Deserializar objeto a string json, coche1
        Gson gson = new Gson();
//
//        json = gson.toJson(coche1);
//        doc = Document.parse(json);
//        coleccion.insertOne(doc);
//
//
//        //Deserializar coche2
//        json = gson.toJson(coche2);
//        doc = Document.parse(json);
//        coleccion.insertOne(doc);

        // Recuperar para asegurarse de que se insertó el objeto
        MongoCursor<Document> buscarColeccion = coleccion.find().iterator();

        try{
            Coche guardarCoches=gson.fromJson(buscarColeccion.next().toJson(),Coche.class);
            System.out.println(guardarCoches.toString());

        }finally {
            buscarColeccion.close();
        }

        launch();

    }
}