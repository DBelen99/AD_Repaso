package org.example.crud_gestioncoches;


//metods estaticos
public class Validar {
}
